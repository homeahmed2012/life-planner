self.__precacheManifest = [
  {
    "revision": "f70fbb4b460385a1418a",
    "url": "/static/static/js/runtime~main.647f6be3.js"
  },
  {
    "revision": "c6464f27d77ff6340036",
    "url": "/static/static/js/main.61553226.chunk.js"
  },
  {
    "revision": "dfa5e2ed7595d3da00a0",
    "url": "/static/static/js/2.6269e02a.chunk.js"
  },
  {
    "revision": "c6464f27d77ff6340036",
    "url": "/static/static/css/main.ddd3dd4b.chunk.css"
  },
  {
    "revision": "dfa5e2ed7595d3da00a0",
    "url": "/static/static/css/2.58ba0af6.chunk.css"
  },
  {
    "revision": "2dd2932350a45d92fd60d833ef10fb27",
    "url": "/static/index.html"
  }
];